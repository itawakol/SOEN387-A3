package com.example.assignment2.Mapper;
import com.example.assignment2.Bean.EnrolledIn;

public class EnrolledInMapper extends InheritanceMapper{

    public static String Insert1(EnrolledIn enrolledIn, String courseCode) {
        String insert = "UPDATE enrolledIn SET courseCode1='"+courseCode+"' WHERE studentID='" + enrolledIn.getStudentID()+"'";

        return insert;
    }

    public static String Insert2(EnrolledIn enrolledIn, String courseCode) {
        String insert = "UPDATE enrolledIn SET courseCode2='"+courseCode+"' WHERE studentID='" + enrolledIn.getStudentID()+"'";

        return insert;
    }

    public static String Insert3(EnrolledIn enrolledIn, String courseCode) {
        String insert = "UPDATE enrolledIn SET courseCode3='"+courseCode+"' WHERE studentID='" + enrolledIn.getStudentID()+"'";

        return insert;
    }

    public static String Insert4(EnrolledIn enrolledIn, String courseCode) {
        String insert = "UPDATE enrolledIn SET courseCode4='"+courseCode+"' WHERE studentID='" + enrolledIn.getStudentID()+"'";

        return insert;
    }

    public static String Insert5(EnrolledIn enrolledIn, String courseCode) {
        String insert = "UPDATE enrolledIn SET courseCode5='"+courseCode+"' WHERE studentID='" + enrolledIn.getStudentID()+"'";

        return insert;
    }

    public static String Delete1(EnrolledIn student, String courseCode) {

        String delete= "UPDATE enrolledIn SET courseCode1 = '' WHERE studentID='"+student.getStudentID()+"'AND courseCode1 ='" + courseCode+"'";
        return delete;
    }

    public static String Delete2(EnrolledIn student, String courseCode) {
        String delete= "UPDATE enrolledIn SET courseCode2 = '' WHERE studentID='"+student.getStudentID()+"'AND courseCode2 ='" + courseCode+"'";
       return delete;
    }

    public static String Delete3(EnrolledIn student, String courseCode) {
        String delete= "UPDATE enrolledIn SET courseCode3 = '' WHERE studentID='"+student.getStudentID()+"'AND courseCode3 ='" + courseCode+"'";
        return delete;
    }

    public static String Delete4(EnrolledIn student, String courseCode) {
        String delete= "UPDATE enrolledIn SET courseCode4 = '' WHERE studentID='"+student.getStudentID()+"'AND courseCode4 ='" + courseCode+"'";
        return delete;
    }
    public static String Delete5(EnrolledIn student, String courseCode) {
        String delete= "UPDATE enrolledIn SET courseCode5 = '' WHERE studentID='"+student.getStudentID()+"'AND courseCode5 ='" + courseCode+"'";
        return delete;
    }

    public String Find (EnrolledIn enrolledIn) {
        String find = "SELECT studentID, courseCode1, courseCode2, courseCode3, courseCode4,courseCode5 FROM enrolledIn WHERE studentID ="+enrolledIn.getStudentID();
        return find;
    }

    public String FindCourseList(EnrolledIn enrolledIn) {
        String find = "SELECT studentID, courseCode1, courseCode2, courseCode3, courseCode4, courseCode5 FROM enrolledIn WHERE studentID=" + enrolledIn.getStudentID();
        return find;
    }


}

