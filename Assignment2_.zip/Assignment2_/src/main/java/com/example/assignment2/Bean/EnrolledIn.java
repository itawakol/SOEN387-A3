package com.example.assignment2.Bean;

public class EnrolledIn {

    private static final long serialVersionUID = 1;
    private String studentID;
    private String courseCode1;
    private String courseCode2;
    private String courseCode3;
    private String courseCode4;
    private String courseCode5;

    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public String getCourseCode1() {
        return courseCode1;
    }

    public void setCourseCode1(String courseCode1) {
        this.courseCode1 = courseCode1;
    }

    public String getCourseCode2() {
        return courseCode2;
    }

    public void setCourseCode2(String courseCode2) {
        this.courseCode2 = courseCode2;
    }

    public String getCourseCode3() {
        return courseCode3;
    }

    public void setCourseCode3(String courseCode3) {
        this.courseCode3 = courseCode3;
    }

    public String getCourseCode4() {
        return courseCode4;
    }

    public void setCourseCode4(String courseCode4) {
        this.courseCode4 = courseCode4;
    }

    public String getCourseCode5() {
        return courseCode5;
    }

    public void setCourseCode5(String courseCode5) {
        this.courseCode5 = courseCode5;
    }
}
