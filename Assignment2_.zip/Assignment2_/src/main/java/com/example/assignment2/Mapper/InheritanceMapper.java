package com.example.assignment2.Mapper;

public class InheritanceMapper {
    public String Find() {

        String find="";
        return find;
    }
    public String Update() {

        String update="";
        return update;
    }
    public String Insert() {

        String insert="";
        return insert;
    }
    public String Delete() {

        String delete="";
        return delete;
    }
}
